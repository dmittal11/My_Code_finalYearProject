<?php

class UnitTestCase extends CIPHPUnitTestUnitTestCase
{
}
