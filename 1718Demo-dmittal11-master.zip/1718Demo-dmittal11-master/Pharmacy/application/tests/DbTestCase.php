<?php

class DbTestCase extends CIPHPUnitTestDbTestCase
{
}
